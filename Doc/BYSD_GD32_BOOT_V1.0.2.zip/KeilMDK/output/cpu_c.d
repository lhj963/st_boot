.\output\cpu_c.o: ..\Source\os\cpu_c.c
.\output\cpu_c.o: ..\Source\os\lfos_cfg.h
.\output\cpu_c.o: ..\Source\os\lfos.h
