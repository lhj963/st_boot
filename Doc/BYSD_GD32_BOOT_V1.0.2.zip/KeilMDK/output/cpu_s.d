.\output\cpu_s.o: ..\Source\os\cpu_s.s
