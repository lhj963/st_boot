.\output\lfos.o: ..\Source\os\lfos.c
.\output\lfos.o: ..\Source\os\lfos.h
.\output\lfos.o: ..\Source\os\lfos_cfg.h
