.\output\startup_stm32f10x_hd.o: ..\Source\device\startup_stm32f10x_hd.s
