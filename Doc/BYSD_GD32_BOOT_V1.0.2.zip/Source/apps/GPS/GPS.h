#ifndef __GPS_H__
#define __GPS_H__

#ifdef __cplusplus
extern "C" {
#endif



extern int GPS_Init(int bps,int iParity);


extern int GPS_Analyze(void *buf);

extern void DispGpsInfo(void);


//�Ƿ�λ
extern char IsPosition(void);


//��ȡGPS�ٶ�
extern INT16U GetGpsSpeed(void);

extern INT16U GetAngle(void);
extern INT8U GetEW(void);
extern INT8U GetNS(void);

//��ȡ����
extern INT32U GetLong(void);
//��ȡγ��
extern INT32U GetLat(void);


#ifdef __cplusplus
}
#endif
#endif

