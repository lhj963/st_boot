#include "moni_spi.h"

/**
cs
mosi
miso
clk
*/
typedef struct tagMONISPI
{
	SETFUNC pSetCLKOutputMode;
	SETFUNC pSetMOSIOutputMode;
	SETFUNC pSetMISOIutputMode;

	SETVALUEFUNC pSetCLK;
	SETVALUEFUNC pSetMOSI;

	READFUNC pReadMISO;

	char CPOL;	//ʱ�Ӽ���  0:ʱ�ӿ���ʱΪ�͵�ƽ  1:ʱ�ӿ���ʱΪ�ߵ�ƽ
	char CPHA;	//ʱ����λ  0:ʱ�����������زɼ����� �½����������     1:ʱ�������½��زɼ����� �������������
	char IsMSBFirst;		//�Ƿ��ȴ����λ
}MONISPI;




MONISPI s_astMONISPI[MAX_SPI_CNT] = {0};



int moni_spi_init(int num,
	SETFUNC pSetCLKOutputMode,
	SETFUNC pSetMOSIOutputMode,
	SETFUNC pSetMISOIutputMode,

	SETVALUEFUNC pSetCLK,
	SETVALUEFUNC pSetMOSI,

	READFUNC pReadMISO,
	char CPOL,
	char CPHA,
	char IsMSBFirst
	)
{
	if (num >= MAX_SPI_CNT)
	{
		return -1;
	}

	s_astMONISPI[num].pSetCLKOutputMode = pSetCLKOutputMode;
	s_astMONISPI[num].pSetMOSIOutputMode = pSetMOSIOutputMode;
	s_astMONISPI[num].pSetMISOIutputMode = pSetMISOIutputMode;

	s_astMONISPI[num].pSetCLK = pSetCLK;
	s_astMONISPI[num].pSetMOSI = pSetMOSI;

	s_astMONISPI[num].pReadMISO = pReadMISO;

	s_astMONISPI[num].CPOL = CPOL;
	s_astMONISPI[num].CPHA = CPHA;
	s_astMONISPI[num].IsMSBFirst = IsMSBFirst;

	//���������������ģʽ
	if (s_astMONISPI[num].pSetCLKOutputMode) s_astMONISPI[num].pSetCLKOutputMode();
	if (s_astMONISPI[num].pSetMOSIOutputMode) s_astMONISPI[num].pSetMOSIOutputMode();
	if (s_astMONISPI[num].pSetMISOIutputMode) s_astMONISPI[num].pSetMISOIutputMode();

	//��ʼ��������״̬
	if (s_astMONISPI[num].CPOL)		//����Ϊ1�� ����״̬Ϊ�ߵ�ƽ
	{
		if (s_astMONISPI[num].pSetCLK) s_astMONISPI[num].pSetCLK(1);
	}
	else							//����Ϊ0�� ����״̬Ϊ�͵�ƽ
	{
		if (s_astMONISPI[num].pSetCLK) s_astMONISPI[num].pSetCLK(0);
	}

	if (s_astMONISPI[num].pSetMOSI) s_astMONISPI[num].pSetMOSI(1);
	return 0;
}


void moni_spi_write_byte(int num,unsigned char dat)
{
	unsigned char i = 0;
	unsigned char temp = 0;
	unsigned char cpol = s_astMONISPI[num].CPOL;
	unsigned char cpha = s_astMONISPI[num].CPHA;
	unsigned char is_msb_first = s_astMONISPI[num].IsMSBFirst;

	for (i = 0; i < 8; i++)
	{
		if (is_msb_first)
		{
			temp = dat & (1 << (7 - i));
		}
		else
		{
			temp = dat & (1 << i);
		}

		if (cpol == 0)		//����Ϊ0
		{
			if (cpha == 0) 	//��λΪ0 �ڵ�һ�����ط�������
			{
				if (temp)
				{
					//if (s_astMONISPI[num].pSetMOSI)
					s_astMONISPI[num].pSetMOSI(1);
				}
				else
				{
					//if (s_astMONISPI[num].pSetMOSI)
					s_astMONISPI[num].pSetMOSI(0);
				}

				//if (s_astMONISPI[num].pSetCLK)
				s_astMONISPI[num].pSetCLK(1);
				//if (s_astMONISPI[num].pSetCLK)
				s_astMONISPI[num].pSetCLK(0);

			}
			#if 1
			else			//��λΪ1 �ڵڶ������ط�������
			{
				//if (s_astMONISPI[num].pSetCLK)
				s_astMONISPI[num].pSetCLK(1);
				if (temp)
				{
					//if (s_astMONISPI[num].pSetMOSI) 
					s_astMONISPI[num].pSetMOSI(1);
				}
				else
				{
					//if (s_astMONISPI[num].pSetMOSI) 
					s_astMONISPI[num].pSetMOSI(0);
				}

				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(0);

			}
			#endif
		}
#if 1
		else				//����Ϊ1
		{
			if (cpha == 0)		//��λΪ0 �ڵ�һ�����ط�������
			{
				if (temp)
				{
					//if (s_astMONISPI[num].pSetMOSI) 
					s_astMONISPI[num].pSetMOSI(1);
				}
				else
				{
					//if (s_astMONISPI[num].pSetMOSI) 
					s_astMONISPI[num].pSetMOSI(0);
				}
				
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(0);
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(1);

			}
			else				//��λΪ1 �ڵڶ������ط�������
			{
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(0);
				if (temp)
				{
					//if (s_astMONISPI[num].pSetMOSI) 
					s_astMONISPI[num].pSetMOSI(1);
				}
				else
				{
					//if (s_astMONISPI[num].pSetMOSI) 
					s_astMONISPI[num].pSetMOSI(0);
				}
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(1);
			}
		}
#endif
	}

}


unsigned char moni_spi_read_byte(int num)
{
	unsigned char i = 0;
	unsigned char dat = 0;
	unsigned char temp = 0;
	unsigned char cpol = s_astMONISPI[num].CPOL;
	unsigned char cpha = s_astMONISPI[num].CPHA;
	unsigned char is_msb_first = s_astMONISPI[num].IsMSBFirst;


	for (i = 0; i < 8; i++)
	{
		if (cpol == 0)			//����Ϊ0	����״̬��ƽΪ0
		{
			if (cpha == 0)		//��λΪ0 ��һ�����ؽ����ݶ���
			{
				//if (s_astMONISPI[num].pSetCLK)
				{
					s_astMONISPI[num].pSetCLK(1);
				}
				//if (s_astMONISPI[num].pReadMISO)
				{
					temp = s_astMONISPI[num].pReadMISO();
				}
				//if (s_astMONISPI[num].pSetCLK)
				{
					s_astMONISPI[num].pSetCLK(0);
				}
			}
			else				//��λΪ1 �ڶ������ؽ����ݶ���
			{
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(1);
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(0);
				//if (s_astMONISPI[num].pReadMISO) 
				temp = s_astMONISPI[num].pReadMISO();
			}
		}
		else					//����Ϊ1 ����״̬��ƽΪ1
		{
			if (cpha == 0)		//��λΪ0 ��һ�����ؽ����ݶ���
			{
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(0);
				//if (s_astMONISPI[num].pReadMISO) 
				temp = s_astMONISPI[num].pReadMISO();
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(1);
			}
			else				//��λΪ1 �ڶ������ؽ����ݶ���
			{
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(0);
				//if (s_astMONISPI[num].pSetCLK) 
				s_astMONISPI[num].pSetCLK(1);
				//if (s_astMONISPI[num].pReadMISO) 
				temp = s_astMONISPI[num].pReadMISO();
			}

		}

		if (is_msb_first)
		{
			if (temp)
			{
				dat |= (1 << (7 - i));
			}
		}
		else
		{
			if (temp)
			{
				dat |= (1 << i);
			}
		}	
	}

	return dat;
}




